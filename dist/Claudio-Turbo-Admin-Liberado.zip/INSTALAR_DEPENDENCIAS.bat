@echo off
title Claudio Turbo - Instalador de Dependencias
cd /d "%~dp0"
echo ========================================================
echo   Instalando Dependencias do Claudio Turbo no seu PC
echo ========================================================
echo.

node -v >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [!] Node.js nao encontrado. Baixe em https://nodejs.org e instale.
    pause
    exit /b
)

echo [*] Instalando Claude Code no seu sistema...
call npm install -g @anthropic-ai/claude-code

echo.
echo [?] Tudo pronto! Agora de 2 cliques em '?? Claudio.exe' para usar!
pause
