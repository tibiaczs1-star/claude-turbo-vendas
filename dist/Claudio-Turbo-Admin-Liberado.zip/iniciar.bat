@echo off
title Claudio Turbo - Modo Admin VIP
cd /d "%~dp0"
start "" "?? Claudio.exe"
